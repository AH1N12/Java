package Comparable;

public class SortHuman {

	public static void main(String[] args) {
		

	}

}
