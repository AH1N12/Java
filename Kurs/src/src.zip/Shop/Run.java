package Shop;

public class Run {

	public static void main(String[] args) {
		Shop shop = new Shop();
		shop.addProduct("kurczak", 12.23);
		shop.addProduct("kurck", 12.23);
		shop.addProduct("kurc22222k", 12.23);
		try {
			System.out.println(shop.readInfo());
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
//Zbudowac aplikacje sklep.
//W sklepie mozemy obejrzec stan magazynu
//Ustalic ceny towaru
//Dokonac sprzedarzy
//Przyjac towar
//Stan magazynu musi byc zachowany mi�dzy wykonaniami programu
//
