package Shop;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

public class Shop {
	private List<Product> products = new ArrayList<Product>();

	public void addProduct(String name, double price) {
		String[] splitter = Double.toString(price).split("\\."); // moze byc
																	// problem
		if (splitter[1].length() <= 2) {
			Product p = new Product(name, price);
			products.add(p);
			try {
				writeInfo(p);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return;
		}
		System.out.println("Niepoprawny format ceny! Nie dodano produktu.");

	}

	public String lookAtStorehause() {

		return "zwracam";
	}

	public void sell(Product p) {

	}

	private void writeInfo(Product p) throws Exception {
		File storehouse = new File("Storehouse.txt");	
		OutputStreamWriter str = new OutputStreamWriter(new FileOutputStream(storehouse,true ));
		str.append(p.toString()+">");
		str.close();

	}

	@SuppressWarnings("null")
	public String readInfo() throws Exception { // private
		StringBuilder tmp=null;
		BufferedReader str= new BufferedReader(new FileReader("Storehouse.txt"));
		String line;
		while ((line = str.readLine()) != null) { //moze byc problem
			System.out.println(line);
			tmp.append(line);			
		}
		str.close();			
		return tmp.toString();
	}

}
