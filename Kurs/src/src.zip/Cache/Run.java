package Cache;

import java.util.List;
import java.util.ArrayList;

public class Run {

	public static void main(String[] args) {
		int a =7;
		int b = 8;
		int c = 3;
		List<Integer> list = new ArrayList<Integer>();
		list.add(a);
		list.add(b);
		list.add(c);
		Cache.add(list);

	}

}
//Zaimplementowac parametryzowany cache kt�ry b�dzie czy�ci� 
//warto�ci kt�re nie zosta�y odczytane w przeciagu 10 sekund
//
//watki