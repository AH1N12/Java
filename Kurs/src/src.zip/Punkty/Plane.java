package Punkty;

public class Plane {
	private Point[] plane;

	public Plane(Point[] p) {
		plane = p;
	}
	public Point[] getPlane(){
		return plane;
	}
	
}