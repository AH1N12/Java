package Punkty;

public class Main {

	public static void main(String[] args) {
		
		Point table[] = {new Point(0,0),new Point(0,4),new Point(2,0),new Point(3,0)};
		
		System.out.println(Find.nearestPoints(new Plane(table)));
	}

}
