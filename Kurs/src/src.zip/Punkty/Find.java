package Punkty;

public class Find {

	public static double nearestPoints(Plane plane) {

		Point temp;
		double distance = 5.0;
		// System.out.println(distance);
		for (int i = 0; i < plane.getPlane().length; i++) {
			Point current = plane.getPlane()[i];
			for (int j = 0; j < plane.getPlane().length; j++) {
				if (j == i)
					continue;
				temp = (plane.getPlane()[j]);

				if (distance >= current.Distance(temp)) {

					distance = current.Distance(temp);
				}
			}

		}

		return distance;
	}

	public double farestPoints() {

		return Integer.MAX_VALUE;
	}
}
