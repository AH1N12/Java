package Comparable;

public class Human implements Comparable<Human> {
		Integer wiek;
		String name, surname;
	


	public int compareTo(Human o) {
		//if()
		
		return 0;
	}
	
public static void main(String[] args) {
		

	}

}
