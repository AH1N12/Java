package Exceptions;

public class Tester {

	public static void main(String[] args) {
		UrlFromString url= new UrlFromString();
		url.check1("");
		//url.check2("www");
	}

}
